<?php
// 投票功能
if (!defined('ABSPATH')) exit;

require_once get_template_directory() . '/inc/notifications.php';

// 创建投票表
function create_voting_tables() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // 投票表
    $sql_votes = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}post_votes (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        post_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        vote_type tinyint(1) NOT NULL,
        vote_date datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY post_id (post_id),
        KEY user_id (user_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_votes);
}
register_activation_hook(__FILE__, 'create_voting_tables');

// 检查用户投票权限
function check_user_voting_permission($user_id, $post_id) {
    // 检查用户是否已投票
    if (get_user_vote($user_id, $post_id)) {
        return new WP_Error('already_voted', '您已经对此文章投过票了');
    }
    
    // 检查注册时间
    $min_months = get_option('voting_min_register_months', 3);
    $user = get_userdata($user_id);
    $register_date = strtotime($user->user_registered);
    $months_diff = (time() - $register_date) / (30 * 24 * 60 * 60);
    
    if ($months_diff < $min_months) {
        return new WP_Error('insufficient_time', 
            sprintf('需要注册满%d个月才能参与投票', $min_months));
    }
    
    return true;
}

// 添加投票
function add_vote($post_id, $user_id, $vote_type) {
    global $wpdb;
    
    $permission = check_user_voting_permission($user_id, $post_id);
    if (is_wp_error($permission)) {
        return $permission;
    }
    
    $result = $wpdb->insert(
        $wpdb->prefix . 'post_votes',
        array(
            'post_id' => $post_id,
            'user_id' => $user_id,
            'vote_type' => $vote_type
        ),
        array('%d', '%d', '%d')
    );
    
    if ($result === false) {
        return new WP_Error('vote_failed', '投票失败');
    }
    
    // 检查是否达到投票阈值
    check_voting_threshold($post_id);
    
    return true;
}

// 获取用户投票
function get_user_vote($user_id, $post_id) {
    global $wpdb;
    
    return $wpdb->get_var($wpdb->prepare(
        "SELECT vote_type FROM {$wpdb->prefix}post_votes 
         WHERE user_id = %d AND post_id = %d",
        $user_id, $post_id
    ));
}

// 检查投票阈值
function check_voting_threshold($post_id) {
    global $wpdb;
    
    $required_votes = get_option('voting_votes_required', 10);
    $approve_ratio = get_option('voting_approve_ratio', 0.6);
    
    $votes = $wpdb->get_results($wpdb->prepare(
        "SELECT vote_type, COUNT(*) as count 
         FROM {$wpdb->prefix}post_votes 
         WHERE post_id = %d 
         GROUP BY vote_type",
        $post_id
    ));
    
    $total_votes = 0;
    $approve_votes = 0;
    
    foreach ($votes as $vote) {
        $total_votes += $vote->count;
        if ($vote->vote_type == 1) {
            $approve_votes = $vote->count;
        }
    }
    
    // 如果达到所需票数
    if ($total_votes >= $required_votes) {
        $ratio = $approve_votes / $total_votes;
        
        if ($ratio >= $approve_ratio) {
            // 通过投票
            wp_update_post(array(
                'ID' => $post_id,
                'post_status' => 'publish'
            ));
            
            // 通知作者
            $post = get_post($post_id);
            add_user_notification(
                $post->post_author,
                sprintf('您的文章《%s》已通过社区投票', $post->post_title),
                'post_approved'
            );
        } else {
            // 拒绝发布
            wp_update_post(array(
                'ID' => $post_id,
                'post_status' => 'draft'
            ));
            
            // 通知作者
            $post = get_post($post_id);
            add_user_notification(
                $post->post_author,
                sprintf('您的文章《%s》未通过社区投票', $post->post_title),
                'post_rejected'
            );
        }
    }
}

// AJAX处理投票
function handle_vote() {
    check_ajax_referer('voting-nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error('请先登录');
        return;
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $vote = isset($_POST['vote']) ? intval($_POST['vote']) : 0;
    $user_id = get_current_user_id();
    
    $result = add_vote($post_id, $user_id, $vote);
    
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
        return;
    }
    
    wp_send_json_success('投票成功');
}
add_action('wp_ajax_handle_vote', 'handle_vote');