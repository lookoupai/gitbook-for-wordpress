<?php
// 引入模块化的功能文件（按依赖顺序）
require_once get_template_directory() . '/inc/notifications.php';      // 最先加载通知系统
require_once get_template_directory() . '/inc/user-center-functions.php'; 
require_once get_template_directory() . '/inc/post-submission.php';    
require_once get_template_directory() . '/inc/post-editing.php';       
require_once get_template_directory() . '/inc/voting-functions.php';   
require_once get_template_directory() . '/inc/voting-settings.php';    

// 设置主题默认特性
function my_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('align-wide');
    
    // 注册导航菜单
    register_nav_menus(array(
        'primary' => __('顶部菜单', 'your-theme-text-domain'),
        'sidebar' => __('侧边栏菜单', 'your-theme-text-domain')
    ));

    // HTML5支持
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
}
add_action('after_setup_theme', 'my_theme_setup');

// 资源加载
function my_theme_enqueue_scripts() {
    // 主样式表
    wp_enqueue_style('my-theme-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));

    // Bootstrap
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '5.3.0');
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '5.3.0', true);

    // 自定义脚本和样式
    wp_enqueue_script('custom-scripts', get_template_directory_uri() . '/js/custom-scroll-sidebar-scripts.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('search-form', get_template_directory_uri() . '/search-form.js', array(), '1.0', true);
    wp_enqueue_style('nav-menu-styles', get_template_directory_uri() . '/assets/css/nav-menu.css');

    // 条件加载
    if (is_page_template(array('page-login.php', 'page-register.php', 'page-lost-password.php'))) {
        wp_enqueue_style('login-register-styles', get_template_directory_uri() . '/assets/css/login-register.css');
    }
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_scripts');

// 小工具注册
function my_theme_widgets_init() {
    register_sidebar(array(
        'name'          => '《求和!李姐万岁!》主题自定义小部件',
        'id'            => 'right-sidebar',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'my_theme_widgets_init');

// 创建主题页面
function create_theme_pages() {
    $pages = array(
        'user-center' => array(
            'title' => '用户中心',
            'template' => 'page-user-center.php'
        ),
        'login' => array(
            'title' => '登录',
            'template' => 'page-login.php'
        ),
        'register' => array(
            'title' => '注册',
            'template' => 'page-register.php'
        ),
        'lost-password' => array(
            'title' => '忘记密码',
            'template' => 'page-lost-password.php'
        ),
        'submit-post' => array(
            'title' => '投稿',
            'template' => 'page-submit-post.php'
        ),
        'edit-post' => array(
            'title' => '编辑文章',
            'template' => 'page-edit-post.php'
        ),
        'comment' => array(
            'title' => '编辑评论',
            'template' => 'page-comment.php'
        ),
        'community-voting' => array(
            'title' => '社区投票',
            'template' => 'page-community-voting.php'
        )
    );

    foreach ($pages as $slug => $page) {
        if (!get_page_by_path($slug)) {
            wp_insert_post(array(
                'post_title'    => $page['title'],
                'post_name'     => $slug,
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_content'  => '',
                'page_template' => $page['template']
            ));
        }
    }
}
add_action('after_switch_theme', 'create_theme_pages');

// URL重写
function custom_login_url($login_url) {
    $page = get_page_by_path('login');
    return $page ? get_permalink($page) : $login_url;
}
add_filter('login_url', 'custom_login_url', 10, 1);

function custom_register_url($register_url) {
    $page = get_page_by_path('register');
    return $page ? get_permalink($page) : $register_url;
}
add_filter('register_url', 'custom_register_url', 10, 1);

function custom_lostpassword_url($lostpassword_url) {
    $page = get_page_by_path('lost-password');
    return $page ? get_permalink($page) : $lostpassword_url;
}
add_filter('lostpassword_url', 'custom_lostpassword_url', 10, 1);

// 访问控制
function check_user_center_access() {
    if (is_page('user-center') && !is_user_logged_in()) {
        wp_redirect(add_query_arg(
            'redirect_to', 
            urlencode(get_permalink(get_page_by_path('user-center'))), 
            get_permalink(get_page_by_path('login'))
        ));
        exit;
    }
}
add_action('template_redirect', 'check_user_center_access');

// 性能优化
function optimize_post_pages() {
    if (is_page_template(['page-submit-post.php', 'page-edit-post.php'])) {
        wp_enqueue_script('jquery');
        
        // 移除不必要的资源
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('wp-block-library-theme');
        wp_dequeue_style('wc-block-style');
        wp_dequeue_style('global-styles');
        
        // 预加载
        add_action('wp_head', function() {
            ?>
            <link rel="preload" href="https://cdn.jsdelivr.net/npm/markdown-it@13.0.1/dist/markdown-it.min.js" as="script">
            <link rel="preconnect" href="https://cdn.jsdelivr.net">
            <link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
            <?php
        });

        // 延迟加载
        add_filter('script_loader_tag', function($tag, $handle) {
            if (!in_array($handle, ['jquery', 'markdown-it'])) {
                return str_replace(' src', ' defer src', $tag);
            }
            return $tag;
        }, 10, 2);
    }
}
add_action('wp_enqueue_scripts', 'optimize_post_pages', 100);

// 编码和缓存控制
function ensure_correct_encoding() {
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
}
add_action('template_redirect', 'ensure_correct_encoding');

// 禁用新用户注册邮件通知
add_filter('wp_new_user_notification_email', '__return_false');
add_filter('wp_new_user_notification_email_admin', '__return_false');