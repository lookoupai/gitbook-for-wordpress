<div class="left-sidebar d-none d-lg-block">
    <?php require 'left-sidebar.php'; ?>
</div>